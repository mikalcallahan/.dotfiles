module.exports.colors = {{
  dark: {{
    accent0: "{color0}",
    accent1: "{color1}",
    accent2: "{color2}",
    accent3: "{color3}",
    accent4: "{color4}",
    accent5: "{color5}",
    accent6: "{cursor}",
    accent7: "{color7}",
    shade0:  "{background}",
    shade1:  "{color9}",
    shade2:  "{color10}",
    shade3:  "{color11}",
    shade4:  "{color12}",
    shade5:  "{color13}",
    shade6:  "{color14}",
    shade7:  "{foreground}"
  }},
}};
